var examples = ['01_CapabilitiesDetectionExample01.htm',
'02_QuirksDetectionExample01.htm',
'03_client.html'];