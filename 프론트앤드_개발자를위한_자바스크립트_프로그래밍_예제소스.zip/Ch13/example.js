function sayHi(){
    console.log("hi!");
}