var examples = ['01_SelectorsAPIExample01.htm',
'02_SelectorsAPIExample02.htm',
'03_SelectorsAPIExample03.htm',
'04_OuterHTMLExample01.htm',
'05_ContainsExample02.htm',
'06_InnerTextExample01.htm',
'07_InnerTextExample02.htm',
'08_InnerTextExample03.htm',
'09_InnerTextExample05.htm'];